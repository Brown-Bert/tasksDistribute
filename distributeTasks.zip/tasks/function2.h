#ifndef FUNCTION2_H_
#define FUNCTION2_H_
#include <iostream>

extern "C" void myprint(std::string strs);

#endif