#ifndef FUNCTION1_H_
#define FUNCTION1_H_
#include <iostream>

extern "C" void myprint(std::string strs);

#endif